// ========================================
// 花语者 v4.8b - C3 节点 5 分钟循环版（light sleep 省电测试版）
// ★ 基于 v4.7（5 分钟循环稳定版），仅把间隔期空转改为 light sleep ★
// ★ v4.8b 修复：millis() 在 light sleep 期间不走，改 RTC 定时器唤醒计数 ★
// ★ 测试：子机1（弱苗），先单节点验证母机稳定接收，再推广 ★
// 无 ACK，连发 3 次冗余保证送达
// ========================================

#include <esp_now.h>
#include <WiFi.h>
#include <esp_wifi.h>

#define SENSOR_POWER 4
#define SENSOR_SIGNAL 0

// ★ 弱苗=1 病苗=2 生桩=3  （本版测试用子机1=弱苗）
#define NODE_ID 1

// ★ 发送间隔：5 分钟
// 用 RTC 定时器唤醒计数：每 100ms 醒一次，3000 次 = 300 秒 = 5 分钟
#define SLEEP_SLICE_US  100000   // 100ms（微秒）
#define WAKE_COUNT_MAX  3000     // 3000 × 100ms = 5 分钟

uint8_t broadcast[] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

struct SensorData {
  uint8_t node_id;
  int moisture;
};

int readSensor() {
  pinMode(SENSOR_POWER, OUTPUT);
  digitalWrite(SENSOR_POWER, HIGH);
  delay(100);
  int val = analogRead(SENSOR_SIGNAL);
  digitalWrite(SENSOR_POWER, LOW);
  return val;
}

void setup() {
  Serial.begin(115200);
  delay(500);
  analogReadResolution(12);

  Serial.printf("\n--- C3 节点 #%d [5min lightsleep v4.8b] ---\n", NODE_ID);

  WiFi.mode(WIFI_STA);
  esp_wifi_set_ps(WIFI_PS_NONE);

  if (esp_now_init() != ESP_OK) {
    Serial.println("ESP-NOW init FAIL");
    return;
  }

  esp_now_peer_info_t peer;
  memset(&peer, 0, sizeof(peer));
  memcpy(peer.peer_addr, broadcast, 6);
  peer.channel = 1;
  peer.encrypt = false;
  esp_now_add_peer(&peer);

  // 三节点错开启动发送时间
  int startupDelay = (NODE_ID - 1) * 5000;
  delay(startupDelay);

  Serial.println("就绪，每5分钟发送（间隔期 light sleep）");
}

void loop() {
  // ★ v4.8b 修复：millis() 在 light sleep 期间不走，绝不能用它判断时间
  // 改用 RTC 定时器唤醒计数：唤醒一次计一次，计满 3000 次（=5 分钟）才发送
  static uint32_t wakeCount = 0;
  if (wakeCount < WAKE_COUNT_MAX) {
    wakeCount++;
    esp_sleep_enable_timer_wakeup(SLEEP_SLICE_US);
    esp_light_sleep_start();
    return;
  }
  wakeCount = 0;

  // ★ 唤醒后等 WiFi 射频恢复，避免头几次发送失败
  delay(50);

  SensorData data;
  data.node_id = NODE_ID;
  data.moisture = readSensor();

  // 连发 3 次冗余，提高送达率
  for (int i = 0; i < 3; i++) {
    esp_err_t r = esp_now_send(broadcast, (uint8_t*)&data, sizeof(data));
    if (r == ESP_OK) {
      Serial.printf("节点%d => %d OK\n", NODE_ID, data.moisture);
    } else {
      Serial.printf("节点%d FAIL\n", NODE_ID);
    }
    delay(200);
  }
}
