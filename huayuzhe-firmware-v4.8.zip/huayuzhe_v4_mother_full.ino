// ===== 脱敏版（公开提交用）=====
// 原固件含真实 WiFi 密码 / 飞书密钥 / DeepSeek Key，
// 本版本已替换为占位符。烧录前请填写你自己的配置（见下方配置区）。
// ========================================
// 花语者 v4 完整版
// 三角梅3路湿度监测(ESP-NOW无线) + 飞书表格 + 飞书IM双向聊天
// + DeepSeek AI + 早安提醒 + 三路电磁阀独立浇水
// IRLZ44N + 1N5819 + 1kΩ下拉
// v4 升级：三路传感器改为 ESP-NOW 无线子节点（C3 SuperMini）
// ========================================

#include <WiFi.h>
#include <HTTPClient.h>
#include <WebServer.h>
#include <ArduinoJson.h>
#include "time.h"
#include <esp_now.h>
#include <esp_wifi.h>

// ====== WiFi ======
const char* WIFI_SSID = "你的WiFi名称";
const char* WIFI_PASS = "你的WiFi密码";

// ====== NTP ======
const char* NTP_SERVER     = "ntp.aliyun.com";
const long  GMT_OFFSET_SEC = 8 * 3600;

// ====== 飞书 ======
const char* FEISHU_APP_ID     = "cli_你的飞书应用ID";
const char* FEISHU_APP_SECRET = "你的飞书应用密钥";
const char* BITABLE_APP_TOKEN = "你的多维表格Token";
const char* TABLE_ID          = "tbl你的表格ID";
String FEISHU_TOKEN = "";

// ====== 传感器（本地ADC回退用，主数据源改为无线） ======
#define S1_PIN 34
#define S2_PIN 35
#define S3_PIN 32

// ====== 执行器 ======
#define RELAY_PIN 14   // 继电器+水泵（经2N2222三极管反相，HIGH=吸合）
#define MOS1_PIN 26    // 电磁阀1-弱苗（IRLZ44N直驱，HIGH=开阀）
#define MOS2_PIN 27    // 电磁阀2-病苗（IRLZ44N直驱，HIGH=开阀）
#define MOS3_PIN 33    // 电磁阀3-生桩（IRLZ44N直驱，HIGH=开阀）

// ====== 定时 ======
unsigned long lastUploadMs = 0;
unsigned long lastCheckMs  = 0;
#define UPLOAD_INTERVAL_MS 1800000
#define IM_CHECK_INTERVAL_MS 5000

// ====== Web 服务器 ======
WebServer server(80);
int s1Val = 0, s2Val = 0, s3Val = 0;

// ====== MiniClaw 飞书IM ======
String lastMsgId = "";
String targetChatId = "";
unsigned long long bootTimeMs = 0;

// ====== 早安提醒 ======
int lastReminderDay = -1;
#define REMINDER_HOUR 8
#define REMINDER_MIN  10

// ★★★ 你的飞书 Open ID ★★★
String MY_OPEN_ID = "ou_你的open_id";

// ========================================
// ★★★ v4 新增：ESP-NOW 无线传感器接收 ★★★
// ========================================
volatile int s1_wireless = -1;
volatile int s2_wireless = -1;
volatile int s3_wireless = -1;

struct SensorData {
  uint8_t node_id;
  int moisture;
};

// 回调里只更新变量，不打印（打印阻塞会导致丢包）
void onDataRecv(const esp_now_recv_info_t *info, const uint8_t *incoming, int len) {
  if (len != sizeof(SensorData)) return;
  SensorData data;
  memcpy(&data, incoming, sizeof(data));

  switch (data.node_id) {
    case 1: s1_wireless = data.moisture; break;
    case 2: s2_wireless = data.moisture; break;
    case 3: s3_wireless = data.moisture; break;
  }
}

void initEspNow() {
  Serial.print("WiFi channel: "); Serial.println(WiFi.channel());
  esp_wifi_set_ps(WIFI_PS_NONE);

  if (esp_now_init() != ESP_OK) {
    Serial.println("ESP-NOW init FAIL");
    return;
  }
  esp_now_register_recv_cb(onDataRecv);

  esp_now_peer_info_t peer;
  memset(&peer, 0, sizeof(peer));
  memcpy(peer.peer_addr, "\xFF\xFF\xFF\xFF\xFF\xFF", 6);
  peer.channel = WiFi.channel();
  peer.encrypt = false;
  esp_now_add_peer(&peer);

  Serial.println("ESP-NOW 无线接收就绪 (S1/S2/S3 来自 C3 节点)");
}

// ====== 传感器读取（本地回退） ======
int readSensor(int pin) {
  analogRead(pin); delay(5);
  return analogRead(pin);
}

// ====== 湿度获取：无线优先，本地ADC回退 ======
int getMoisture(int idx) {
  int w = (idx == 1) ? s1_wireless : (idx == 2) ? s2_wireless : s3_wireless;
  if (w >= 0) return w;
  int pin = (idx == 1) ? S1_PIN : (idx == 2) ? S2_PIN : S3_PIN;
  return readSensor(pin);
}

// ====== 浇水执行（先开阀 → 开水泵 → 延时 → 关泵 → 关阀） ======
void waterPlant(int mosPin, const char* name) {
  Serial.printf("💧 [%s] 开阀...\n", name);
  digitalWrite(mosPin, HIGH);
  delay(300);

  Serial.printf("💧 [%s] 开水泵...\n", name);
  digitalWrite(RELAY_PIN, HIGH);
  delay(8000);

  Serial.printf("💧 [%s] 关泵...\n", name);
  digitalWrite(RELAY_PIN, LOW);
  delay(300);

  Serial.printf("💧 [%s] 关阀...\n", name);
  digitalWrite(mosPin, LOW);
}

// ====== 时间 ======
unsigned long long getTimestampMs() {
  time_t now; time(&now);
  return (unsigned long long)now * 1000LL;
}

// ====== 飞书 Token ======
unsigned long lastTokenTime = 0;
#define TOKEN_REFRESH_MS 6900000

bool getFeishuToken() {
  HTTPClient http;
  http.begin("https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal");
  http.addHeader("Content-Type", "application/json");
  String body = "{\"app_id\":\"" + String(FEISHU_APP_ID) + "\",\"app_secret\":\"" + String(FEISHU_APP_SECRET) + "\"}";
  int code = http.POST(body);
  if (code == 200) {
    String resp = http.getString();
    int s = resp.indexOf("\"tenant_access_token\":\"") + 23;
    int e = resp.indexOf("\"", s);
    FEISHU_TOKEN = resp.substring(s, e);
    lastTokenTime = millis();
    http.end(); return true;
  }
  Serial.print("[Token] err "); Serial.println(code);
  http.end(); return false;
}

void ensureFeishuToken() {
  if (FEISHU_TOKEN != "" && millis() - lastTokenTime < TOKEN_REFRESH_MS) return;
  Serial.print("[Token] refreshing... ");
  if (getFeishuToken()) Serial.println("OK");
  else Serial.println("FAIL");
}

// ====== 上传飞书表格 ======
void uploadToFeishu(int s1, int s2, int s3) {
  ensureFeishuToken();
  if (FEISHU_TOKEN == "") return;
  unsigned long long ts = getTimestampMs();
  HTTPClient http;
  String url = "https://open.feishu.cn/open-apis/bitable/v1/apps/" + String(BITABLE_APP_TOKEN) + "/tables/" + String(TABLE_ID) + "/records";
  http.begin(url);
  http.addHeader("Authorization", "Bearer " + FEISHU_TOKEN);
  http.addHeader("Content-Type", "application/json");
  String body = "{\"fields\":{";
  body += "\"弱苗湿度(S1)\":" + String(s1) + ",";
  body += "\"病苗湿度(S2)\":" + String(s2) + ",";
  body += "\"生桩湿度(S3)\":" + String(s3) + ",";
  body += "\"记录时间\":" + String(ts) + "}}";
  int code = http.POST(body);
  Serial.println(code == 200 ? "[Table] OK" : "[Table] FAIL");
  http.end();
}

// ====== 湿度翻译 ======
String statusText(int val) {
  if (val < 1600) return "偏湿";
  if (val < 2100) return "微润";
  if (val < 2500) return "偏干";
  return "很干";
}

// ====== JSON 提取 ======
String extractJSONString(String json, String key) {
  int p = json.indexOf(key);
  if (p < 0) return "";
  p = json.indexOf(':', p + key.length()) + 1;
  while (p < json.length() && (json[p] == ' ' || json[p] == '"')) p++;
  int end = json.indexOf('"', p);
  if (end < 0) return "";
  return json.substring(p, end);
}

// ====== DeepSeek LLM ======
const char* DS_KEY = "sk-你的DeepSeek密钥";

String callDeepSeek(String userMsg, String context) {
  String prompt = "你是花语者，一位三角梅养护助手。回答准确专业。\n";
  prompt += "【参考信息】" + context + "\n";
  prompt += "【用户的话】" + userMsg + "\n";
  prompt += "简洁回答，80字内。";

  String safe = prompt;
  safe.replace("\\", "\\\\");
  safe.replace("\"", "\\\"");
  safe.replace("\n", "\\n");
  safe.replace("\r", "");

  HTTPClient http;
  http.begin("https://api.deepseek.com/chat/completions");
  http.addHeader("Authorization", "Bearer " + String(DS_KEY));
  http.addHeader("Content-Type", "application/json");
  String body = "{\"model\":\"deepseek-chat\",\"messages\":[{\"role\":\"system\",\"content\":\"你是花语者，三角梅养护助手。回答准确简洁。\"},{\"role\":\"user\",\"content\":\"" + safe + "\"}],\"max_tokens\":200,\"temperature\":0.7}";
  int code = http.POST(body);
  if (code != 200) { http.end(); return ""; }
  String resp = http.getString();
  http.end();
  return extractJSONString(resp, "\"content\"");
}

// ====== 飞书回复 ======
void sendFeishuReply(String chatId, String text) {
  String safe = "";
  for (int i = 0; i < text.length(); i++) {
    char c = text[i];
    if (c == '\\') safe += "\\\\";
    else if (c == '"') safe += "\\\"";
    else if (c == '\n') safe += "\\n";
    else if (c == '\r') { }
    else safe += c;
  }
  String contentJson = "{\"text\":\"" + safe + "\"}";
  static DynamicJsonDocument d(2048);
  d.clear();
  d["receive_id"] = chatId;
  d["msg_type"] = "text";
  d["content"] = contentJson;
  String body;
  serializeJson(d, body);

  HTTPClient http;
  http.begin("https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=chat_id");
  http.addHeader("Authorization", "Bearer " + FEISHU_TOKEN);
  http.addHeader("Content-Type", "application/json");
  int code = http.POST(body);
  if (code != 200) {
    String err = http.getString();
    Serial.printf("[IM] FAIL %d %s\n", code, err.substring(0, 80).c_str());
  } else {
    Serial.println("[IM] OK");
  }
  http.end();
}

// ====== 天气 + 养护规则 (wttr.in) ======
String fetchWeather() {
  HTTPClient http;
  // ====== 天气位置（公开版已脱敏：原硬编码为居住城市，请填你的城市拼音，如 Shenzhen） ======
const char* WEATHER_LOCATION = "你的城市名";
String weatherUrl = "http://wttr.in/" + String(WEATHER_LOCATION) + "?format=%C|%t|%S|%s|%h|%w|%p";
  http.begin(weatherUrl);
  int code = http.GET();
  if (code != 200) { http.end(); return ""; }
  String data = http.getString();
  http.end();
  data.trim();
  return data;
}

String buildMorningReminder() {
  String weather = fetchWeather();
  if (weather == "") return "";

  int p1 = weather.indexOf('|');
  int p2 = weather.indexOf('|', p1+1);
  int p3 = weather.indexOf('|', p2+1);
  int p4 = weather.indexOf('|', p3+1);
  int p5 = weather.indexOf('|', p4+1);
  int p6 = weather.indexOf('|', p5+1);

  String desc  = weather.substring(0, p1);
  String tempS = weather.substring(p1+1, p2);
  String humidS= weather.substring(p4+1, p5);
  String windS = weather.substring(p5+1, p6);
  String precipS = (p6 >= 0) ? weather.substring(p6+1) : "0.0";

  int temp  = tempS.toInt();
  int humid = humidS.toInt();
  // windS可能是 "NW 15" 这样的文字+数字，提取后面的数字
  for (int ci = 0; ci < windS.length(); ci++) {
    if (windS[ci] >= '0' && windS[ci] <= '9') {
      windS = windS.substring(ci); break;
    }
  }
  int wind  = windS.toInt();
  float precip = precipS.toFloat();

  desc.toLowerCase();
  String descCN = desc;
  if (descCN.indexOf("partly cloudy") >= 0) descCN = "多云";
  else if (descCN.indexOf("cloudy") >= 0 || descCN.indexOf("overcast") >= 0) descCN = "阴";
  else if (descCN.indexOf("clear") >= 0 || descCN.indexOf("sunny") >= 0) descCN = "晴";
  else if (descCN.indexOf("light rain") >= 0 || descCN.indexOf("drizzle") >= 0 || descCN.indexOf("shower") >= 0) descCN = "小雨";
  else if (descCN.indexOf("moderate rain") >= 0) descCN = "中雨";
  else if (descCN.indexOf("heavy rain") >= 0) descCN = "大雨";
  else if (descCN.indexOf("thunder") >= 0) descCN = "雷阵雨";
  else if (descCN.indexOf("fog") >= 0 || descCN.indexOf("mist") >= 0) descCN = "雾";
  else if (descCN.indexOf("haze") >= 0 || descCN.indexOf("smoke") >= 0) descCN = "烟霾";

  // 兜底：如果还是英文（包含 a-z），强制翻成"多云"，绝不出现英文
  for (int ci = 0; ci < descCN.length(); ci++) {
    char ch = descCN[ci];
    if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')) {
      descCN = "多云";
      break;
    }
  }

  String windDesc = "";
  if (wind == 0) windDesc = "无风";
  else if (wind <= 5) windDesc = "微风";
  else if (wind <= 19) windDesc = "小风";
  else if (wind <= 38) windDesc = "和风";
  else windDesc = "大风";

  bool isRain  = (descCN.indexOf("雨") >= 0);
  bool isSun   = (descCN == "晴" || descCN == "多云");
  bool isHot   = (temp >= 35);
  bool isWarm  = (temp >= 25);
  bool heavyRain = (descCN.indexOf("大") >= 0 || descCN.indexOf("暴") >= 0);
  bool moderateRain = (descCN.indexOf("中") >= 0);

  String msg = "🌺 花语者：今日养护提醒\n";
  msg += "☀️ " + descCN + " " + String(temp) + "°C  湿" + String(humid) + "%  " + windDesc + String(wind) + "km/h";
  if (precip > 0) msg += "  雨" + String(precip, 1) + "mm";
  else msg += "  无雨";
  msg += "\n\n";

  msg += "💧 浇水: ";
  if (heavyRain || moderateRain) msg += "【高优】有雨停浇";
  else if (isHot && isSun) msg += "【高优】早晚各浇透+盆面覆盖";
  else if (isWarm) msg += "【中优】见干见湿";
  else msg += "【低优】观察";
  msg += "\n";

  msg += "🕶 防晒: ";
  if (isHot && isSun) msg += "【高优】遮阳网30-50% 11-15点";
  else if (temp >= 30 && isSun) msg += "【中优】午后观察";
  else msg += "【低优】无需";
  msg += "\n";

  msg += "☔ 防雨: ";
  if (heavyRain || moderateRain) msg += "【高优】弱苗避雨+查排水";
  else if (isRain) msg += "【中优】小雨无碍";
  else msg += "【低优】放心";
  msg += "\n";

  msg += "🌿 施肥: ";
  if (isHot || isRain) msg += "【高优】停水溶肥缓释减半";
  else msg += "【中优】颗粒缓释+停花倍彩2号";
  msg += "\n";

  msg += "🦟 病虫: ";
  if (temp >= 30 && humid < 70) msg += "【高优】蓟马红蜘蛛高危";
  else if (temp >= 28 && isRain) msg += "【高优】雨后喷苯甲嘧菌酯1500倍";
  else msg += "【低优】日常观察";
  msg += "\n\n";

  // ★ v4: 无线数据优先
  int s1 = getMoisture(1), s2 = getMoisture(2), s3 = getMoisture(3);
  s1Val = s1; s2Val = s2; s3Val = s3;
  msg += "📊 弱苗" + String(s1) + "(" + statusText(s1) + ") 病苗" + String(s2) + "(" + statusText(s2) + ") 生桩" + String(s3) + "(" + statusText(s3) + ")";
  return msg;
}

void checkMorningReminder() {
  struct tm ti;
  if (!getLocalTime(&ti)) return;
  if (ti.tm_hour != REMINDER_HOUR || ti.tm_min < REMINDER_MIN || ti.tm_min >= REMINDER_MIN + 1) return;
  if (ti.tm_mday == lastReminderDay) return;

  unsigned long long nowTs = getTimestampMs();
  if (nowTs - bootTimeMs < 16000) return;

  String msg = buildMorningReminder();
  if (msg == "") return;

  Serial.println("[早安] 发送养护提醒...");
  sendFeishuReply(targetChatId, msg);
  lastReminderDay = ti.tm_mday;
  Serial.println("[早安] 完成");
}

// ====== P2P 通道 ======
bool sendInitMessage(String openId, String text) {
  HTTPClient http;
  http.begin("https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=open_id");
  http.addHeader("Authorization", "Bearer " + FEISHU_TOKEN);
  http.addHeader("Content-Type", "application/json");
  String body = "{\"receive_id\":\"" + openId + "\",\"msg_type\":\"text\",\"content\":\"{\\\"text\\\":\\\"" + text + "\\\"}\"}";
  int code = http.POST(body);
  if (code == 200) {
    String resp = http.getString();
    http.end();
    DynamicJsonDocument d(1024);
    deserializeJson(d, resp);
    if (d["data"]["chat_id"].is<String>()) {
      targetChatId = d["data"]["chat_id"].as<String>();
    }
    if (d["data"]["message_id"].is<String>()) {
      lastMsgId = d["data"]["message_id"].as<String>();
    }
    Serial.printf("[IM] P2P通道建立! chat_id=%s msg_id=%s\n", targetChatId.c_str(), lastMsgId.c_str());
    return true;
  }
  Serial.printf("[IM] 发送失败 code=%d\n", code);
  http.end();
  return false;
}

bool feishuIMReady = false;
void ensureFeishuIMReady() {
  if (feishuIMReady) return;
  if (FEISHU_TOKEN == "" || MY_OPEN_ID.startsWith("ou_你的")) return;
  Serial.printf("[IM] 使用 open_id: %s\n", MY_OPEN_ID.c_str());
  if (sendInitMessage(MY_OPEN_ID, "花语者智能助手已上线，来跟我聊聊您的花儿吧~")) {
    Serial.println("[IM] 启动消息已发送, 请在飞书回复我");
    feishuIMReady = true;
    delay(2000);
  } else {
    Serial.println("[IM] 发送失败, 检查权限 im:message:send_as_bot");
  }
}

// ====== 处理消息 ======
String processMessage(String msg) {
  msg.toLowerCase();
  // ★ v4: 无线数据优先
  int s1 = getMoisture(1);
  int s2 = getMoisture(2);
  int s3 = getMoisture(3);
  s1Val = s1; s2Val = s2; s3Val = s3;

  // ---- 浇水控制（必须放在湿度查询前面） ----
  if (msg.indexOf("浇弱苗") >= 0 || (msg.indexOf("浇") >= 0 && msg.indexOf("弱苗") >= 0)) {
    waterPlant(MOS1_PIN, "弱苗");
    return "💧 弱苗已浇8秒！";
  }
  if (msg.indexOf("浇病苗") >= 0 || (msg.indexOf("浇") >= 0 && msg.indexOf("病苗") >= 0)) {
    waterPlant(MOS2_PIN, "病苗");
    return "💧 病苗已浇8秒！";
  }
  if (msg.indexOf("浇生桩") >= 0 || (msg.indexOf("浇") >= 0 && msg.indexOf("生桩") >= 0)) {
    waterPlant(MOS3_PIN, "生桩");
    return "💧 生桩已浇8秒！";
  }

  // ---- 湿度查询 ----
  if (msg.indexOf("弱苗") >= 0 || msg.indexOf("s1") >= 0) {
    return "弱苗(S1): " + String(s1) + " " + statusText(s1);
  }
  if (msg.indexOf("病苗") >= 0 || msg.indexOf("s2") >= 0) {
    return "病苗(S2): " + String(s2) + " " + statusText(s2);
  }
  if (msg.indexOf("生桩") >= 0 || msg.indexOf("s3") >= 0) {
    return "生桩(S3): " + String(s3) + " " + statusText(s3);
  }
  if (msg.indexOf("全部") >= 0 || msg.indexOf("状态") >= 0 || msg.indexOf("湿度") >= 0) {
    return "弱苗:" + String(s1) + "(" + statusText(s1) + ")  "
           "病苗:" + String(s2) + "(" + statusText(s2) + ")  "
           "生桩:" + String(s3) + "(" + statusText(s3) + ")";
  }

  // 检查模式：问问该不该浇
  if (msg.indexOf("浇") >= 0) {
    bool need = (s1 > 2400 || s2 > 2400 || s3 > 2400);
    if (need) {
      String r = "有花该浇水了: ";
      if (s1 > 2400) r += "弱苗(" + String(s1) + ") ";
      if (s2 > 2400) r += "病苗(" + String(s2) + ") ";
      if (s3 > 2400) r += "生桩(" + String(s3) + ")";
      return r;
    }
    return "湿度都在安全范围，今天不用浇。";
  }

  // ---- 手动早安提醒 ----
  if (msg.indexOf("早安") >= 0 || msg.indexOf("今日提醒") >= 0 || msg.indexOf("养护提醒") >= 0) {
    String reminder = buildMorningReminder();
    if (reminder != "") return reminder;
    return "天气数据暂时取不到，稍后再试～";
  }

  // 指令之外的对话全部交给 DeepSeek（关键词太死板，容易前言不搭后语）
  Serial.println("[DS] 调大模型...");
  String ctx = "你是花语者，一位资深的三角梅养护专家。";
  ctx += "当前传感器: 弱苗" + String(s1) + "(" + statusText(s1) + ") 病苗" + String(s2) + "(" + statusText(s2) + ") 生桩" + String(s3) + "(" + statusText(s3) + ")。";
  ctx += "养护知识: 见干见湿浇水, 高颗粒配土, 6月停花倍彩2号用颗粒缓释肥, >35度遮阳早晚浇, 中雨以上停浇弱苗避雨, >30度干燥蓟马红蜘蛛高危, >28度雨后喷苯甲嘧菌酯。";
  String llmReply = callDeepSeek(msg, ctx);
  if (llmReply != "" && llmReply.length() > 2) {
    return "🧠 " + llmReply;
  }
  return "花语者收到了，但大脑短路了一下。再问一次? 🌺";
}

// ====== 检查飞书IM ======
void checkFeishuIM() {
  ensureFeishuToken();
  if (FEISHU_TOKEN == "") return;
  if (targetChatId == "") return;

  unsigned long long nowTs = getTimestampMs();
  if (nowTs - bootTimeMs < 15000) return;

  HTTPClient http;
  String url = "https://open.feishu.cn/open-apis/im/v1/messages?container_id_type=chat&container_id="
                + targetChatId + "&page_size=3&sort_type=ByCreateTimeDesc";
  http.begin(url);
  http.addHeader("Authorization", "Bearer " + FEISHU_TOKEN);
  int code = http.GET();
  if (code != 200) { http.end(); return; }
  String resp = http.getString();
  http.end();

  DynamicJsonDocument d(4096);
  if (deserializeJson(d, resp)) return;
  JsonArray items = d["data"]["items"].as<JsonArray>();
  if (!items || items.size() == 0) return;

  for (int i = items.size() - 1; i >= 0; i--) {
    JsonObject msg = items[i];
    String msgId   = msg["message_id"].as<String>();
    String msgType = msg["msg_type"].as<String>();
    String senderType = msg["sender"]["id_type"] | "";
    String senderId   = msg["sender"]["id"] | "";

    if (msgId == lastMsgId) continue;
    if (msgType != "text") continue;
    if (senderType == "app" || senderId.startsWith("bot_") || senderId.startsWith("cli_")) continue;

    unsigned long long msgTs = 0;
    if (msg["create_time"].is<unsigned long long>()) {
      msgTs = msg["create_time"].as<unsigned long long>();
    } else if (msg["create_time"].is<const char*>()) {
      msgTs = strtoull(msg["create_time"].as<const char*>(), NULL, 10);
    }
    if (msgTs < bootTimeMs) continue;

    lastMsgId = msgId;

    String raw = msg["body"]["content"].as<String>();
    DynamicJsonDocument cd(512);
    deserializeJson(cd, raw);
    String content = cd["text"].as<String>();
    if (content == "") continue;

    Serial.printf("[IM] >>> %s\n", content.c_str());
    String reply = processMessage(content);
    Serial.printf("[IM] <<< %s\n", reply.c_str());
    sendFeishuReply(targetChatId, reply);
  }
}

// ====== web页面 ======
void handleRoot() {
  String html = R"rawliteral(
<!DOCTYPE html><html lang="zh-CN"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>花语者</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:"PingFang SC","Microsoft YaHei",sans-serif;background:#f3f8ef;min-height:100vh;display:flex;flex-direction:column;align-items:center;padding:20px}
.header{text-align:center;margin:20px 0 24px}
.header .logo{font-size:2.2rem;margin-bottom:4px}
.header h1{font-size:1.3rem;color:#558b3e}
.header .sub{font-size:.78rem;color:#8bb878;margin-top:2px}
.chat-box{width:100%;max-width:420px;background:#fff;border-radius:18px;padding:16px;box-shadow:0 4px 20px rgba(43,58,44,.08);overflow-y:auto;max-height:60vh;margin-bottom:16px;display:flex;flex-direction:column;gap:10px}
.msg{max-width:82%;padding:10px 14px;border-radius:16px;font-size:.88rem;line-height:1.6;word-break:break-word}
.msg.esp32{align-self:flex-start;background:#e6f0dd;color:#33522a;border-bottom-left-radius:4px}
.msg.user{align-self:flex-end;background:#558b3e;color:#fff;border-bottom-right-radius:4px}
.msg .time{font-size:.65rem;opacity:.55;margin-top:4px}
.input-row{width:100%;max-width:420px;display:flex;gap:8px;margin-bottom:12px}
.input-row input{flex:1;padding:12px 16px;border:1px solid #d4e8c8;border-radius:24px;font-size:.9rem;outline:none;background:#fff}
.input-row input:focus{border-color:#8bb878}
.input-row button{padding:12px 20px;background:#558b3e;color:#fff;border:none;border-radius:24px;font-size:.9rem;font-weight:600;cursor:pointer}
.quick-btns{width:100%;max-width:420px;display:flex;flex-wrap:wrap;gap:6px;justify-content:center}
.quick-btns button{padding:6px 14px;font-size:.76rem;border:1px solid #d4e8c8;background:#fff;color:#558b3e;border-radius:16px;cursor:pointer}
.quick-btns button:active{background:#e6f0dd}
</style></head><body>
<div class="header"><div class="logo">🌺</div><h1>花语者 v4</h1><div class="sub">ESP32 + 飞书IM + ESP-NOW 无线三路传感器</div></div>
<div class="chat-box" id="chat"><div class="msg esp32">👋 你好！我是花语者。<br>试试发: 早安 / 浇弱苗 / 弱苗湿度</div></div>
<div class="input-row"><input id="msg" placeholder="输入你的问题..." autofocus><button onclick="send()">发送</button></div>
<div class="quick-btns">
<button onclick="ask('早安')">早安提醒</button>
<button onclick="ask('弱苗湿度')">弱苗湿度</button>
<button onclick="ask('全部状态')">全部状态</button>
<button onclick="ask('浇弱苗')">浇弱苗</button>
<button onclick="ask('浇病苗')">浇病苗</button>
<button onclick="ask('浇生桩')">浇生桩</button>
</div>
<script>
function addMsg(text,who){var d=new Date();var t=d.getHours().toString().padStart(2,'0')+':'+d.getMinutes().toString().padStart(2,'0');var div=document.createElement('div');div.className='msg '+who;div.innerHTML=text+'<div class="time">'+t+'</div>';document.getElementById('chat').appendChild(div)}
function send(){var inp=document.getElementById('msg');var text=inp.value.trim();if(!text)return;addMsg(text,'user');inp.value='';fetch('/chat',{method:'POST',body:new URLSearchParams('m='+encodeURIComponent(text)),headers:{'Content-Type':'application/x-www-form-urlencoded'}}).then(r=>r.text()).then(reply=>{addMsg(reply,'esp32')})}
function ask(q){document.getElementById('msg').value=q;send()}
document.getElementById('msg').addEventListener('keydown',function(e){if(e.key==='Enter')send()})
</script>
</body></html>
)rawliteral";
  server.send(200, "text/html; charset=utf-8", html);
}

void handleChat() {
  String msg = server.arg("m");
  server.send(200, "text/html; charset=utf-8", processMessage(msg));
}

// ====== SETUP ======
void setup() {
  // 第一行就把所有执行器拉低，避免ESP32上电瞬间GPIO浮空误触发
  pinMode(RELAY_PIN, OUTPUT); digitalWrite(RELAY_PIN, LOW);
  pinMode(MOS1_PIN, OUTPUT);  digitalWrite(MOS1_PIN, LOW);
  pinMode(MOS2_PIN, OUTPUT);  digitalWrite(MOS2_PIN, LOW);
  pinMode(MOS3_PIN, OUTPUT);  digitalWrite(MOS3_PIN, LOW);

  Serial.begin(115200);
  delay(1000);
  analogReadResolution(12);

  Serial.println("\n--- 花语者 v4 启动 ---");

  Serial.print("WiFi: ");
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  while (WiFi.status() != WL_CONNECTED) { delay(500); Serial.print("."); }
  Serial.println(" OK!");

  // ★ v4: WiFi 连接后初始化 ESP-NOW 无线接收
  initEspNow();

  Serial.print("NTP: ");
  configTime(GMT_OFFSET_SEC, 0, NTP_SERVER);
  struct tm ti;
  if (getLocalTime(&ti)) {
    Serial.printf("OK %04d-%02d-%02d %02d:%02d:%02d\n",
      ti.tm_year + 1900, ti.tm_mon + 1, ti.tm_mday,
      ti.tm_hour, ti.tm_min, ti.tm_sec);
  } else { Serial.println("FAILED"); }

  Serial.print("Feishu Token: ");
  if (getFeishuToken()) Serial.println("OK");
  else Serial.println("FAILED");

  server.on("/", handleRoot);
  server.on("/chat", handleChat);
  server.begin();
  Serial.println("MiniClaw: WebServer + FeishuIM 双通道就绪");

  // ★ v4: 无线数据优先（C3 未上电时回退本地 ADC）
  s1Val = getMoisture(1); s2Val = getMoisture(2); s3Val = getMoisture(3);
  uploadToFeishu(s1Val, s2Val, s3Val);
  lastUploadMs = millis();
  lastCheckMs  = millis();
  bootTimeMs   = getTimestampMs();
}

// ====== LOOP ======
void loop() {
  server.handleClient();

  if (millis() - lastCheckMs >= IM_CHECK_INTERVAL_MS) {
    ensureFeishuIMReady();
    checkFeishuIM();
    checkMorningReminder();
    lastCheckMs = millis();
  }

  if (millis() - lastUploadMs >= UPLOAD_INTERVAL_MS) {
    // ★ v4: 无线数据优先（C3 未上电时回退本地 ADC）
    s1Val = getMoisture(1); s2Val = getMoisture(2); s3Val = getMoisture(3);
    Serial.printf("[无线] S1:%d S2:%d S3:%d\n", s1Val, s2Val, s3Val);
    uploadToFeishu(s1Val, s2Val, s3Val);
    lastUploadMs = millis();
  }
}
