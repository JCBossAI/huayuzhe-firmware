花语者 · 固件包 v4.8（复赛提交版 · 已脱敏）
============================================

包含 4 个固件：

1. huayuzhe_v4_mother_full.ino          —— 母机完整版（ESP32，接继电器/MOSFET/电磁阀/水泵）
2. huayuzhe_v4_8_c3_5min_lightsleep.ino —— 无线节点 #1（弱苗），light sleep 省电版
3. huayuzhe_v4_8_c3_5min_lightsleep_node2.ino —— 无线节点 #2（病苗）
4. huayuzhe_v4_8_c3_5min_lightsleep_node3.ino —— 无线节点 #3（生桩）

【重要】烧录前必读
------------------
母机固件为脱敏版：原固件包含真实 WiFi 密码 / 飞书应用密钥 /
DeepSeek API Key，为保护隐私已全部替换为占位符。
烧录前请在 huayuzhe_v4_mother_full.ino 顶部配置区填入你自己的配置：

  WIFI_SSID          = 你的 WiFi 名称
  WIFI_PASS          = 你的 WiFi 密码
  FEISHU_APP_ID      = 你的飞书应用 ID（cli_ 开头）
  FEISHU_APP_SECRET  = 你的飞书应用密钥
  BITABLE_APP_TOKEN  = 你的多维表格 Token
  TABLE_ID           = 你的数据表 ID（tbl 开头）
  MY_OPEN_ID         = 你的飞书 open_id（ou_ 开头）
  DS_KEY             = 你的 DeepSeek API Key（sk- 开头）

烧录说明
--------
1. 母机：Arduino IDE 打开 huayuzhe_v4_mother_full，开发板选 ESP32 Dev Module
2. 节点：分别打开对应节点固件，开发板选 ESP32C3 Dev Module（SuperMini 同款）
3. 节点无需改任何参数，NODE_ID 已内置（1=弱苗 / 2=病苗 / 3=生桩）
4. 节点间隔期 light sleep 浅睡（RTC 唤醒计数），3×AA 续航约 3 个月

接线
----
节点：GPIO4 → 传感器 VCC，GPIO0 → 传感器 AOUT，GND → GND
母机接线图见《花语者-ESP-NOW无线节点接线图-AA电池版》
